/*
 * getNewDiscount_terminate.h
 *
 * Code generation for function 'getNewDiscount_terminate'
 *
 */

#ifndef GETNEWDISCOUNT_TERMINATE_H
#define GETNEWDISCOUNT_TERMINATE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "getNewDiscount_types.h"

/* Function Declarations */
extern void getNewDiscount_atexit(void);
extern void getNewDiscount_terminate(void);

#endif

/* End of code generation (getNewDiscount_terminate.h) */
