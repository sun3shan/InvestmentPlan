/*
 * getNewDiscount_data.c
 *
 * Code generation for function 'getNewDiscount_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "getNewDiscount.h"
#include "getNewDiscount_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar = NULL;
emlrtContext emlrtContextGlobal = { true,/* bFirstTime */
  false,                               /* bInitialized */
  131466U,                             /* fVersionInfo */
  NULL,                                /* fErrorFunction */
  "getNewDiscount",                    /* fFunctionName */
  NULL,                                /* fRTCallStack */
  false,                               /* bDebugMode */
  { 2045744189U, 2170104910U, 2743257031U, 4284093946U },/* fSigWrd */
  NULL                                 /* fSigMem */
};

emlrtRSInfo m_emlrtRSI = { 397,        /* lineNo */
  "find",                              /* fcnName */
  "E:\\Program Files\\MATLAB\\R2018a\\toolbox\\eml\\lib\\matlab\\elmat\\find.m"/* pathName */
};

emlrtRSInfo n_emlrtRSI = { 18,         /* lineNo */
  "indexShapeCheck",                   /* fcnName */
  "E:\\Program Files\\MATLAB\\R2018a\\toolbox\\eml\\eml\\+coder\\+internal\\indexShapeCheck.m"/* pathName */
};

emlrtRSInfo v_emlrtRSI = { 258,        /* lineNo */
  "eml_setop",                         /* fcnName */
  "E:\\Program Files\\MATLAB\\R2018a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m"/* pathName */
};

emlrtRSInfo w_emlrtRSI = { 259,        /* lineNo */
  "eml_setop",                         /* fcnName */
  "E:\\Program Files\\MATLAB\\R2018a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m"/* pathName */
};

emlrtRSInfo x_emlrtRSI = { 261,        /* lineNo */
  "eml_setop",                         /* fcnName */
  "E:\\Program Files\\MATLAB\\R2018a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m"/* pathName */
};

emlrtRSInfo y_emlrtRSI = { 459,        /* lineNo */
  "eml_setop",                         /* fcnName */
  "E:\\Program Files\\MATLAB\\R2018a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m"/* pathName */
};

emlrtRSInfo ab_emlrtRSI = { 31,        /* lineNo */
  "safeEq",                            /* fcnName */
  "E:\\Program Files\\MATLAB\\R2018a\\toolbox\\eml\\eml\\+coder\\+internal\\safeEq.m"/* pathName */
};

/* End of code generation (getNewDiscount_data.c) */
